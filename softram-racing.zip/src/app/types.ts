export interface Member {
    id?: number;
    firstName: string;
    lastName: string;
    jobTitle: string;
    team: string;
    status: string;
}
